#ifndef DISPLAYWAVEFORMCH2_H_
#define DISPLAYWAVEFORMCH2_H_


tPushButtonWidget zoomIncButCh2, zoomDecButCh2 , backHomeButWFSCh2 , backFAButWFSCh2, endCh2But ;
tRectangle WFCh2Rect;
extern tRectangle FuncGenRect;

extern char ampStrCh2[10],freqStrCh2[10];
extern float freqCh2;
extern float ampCh2;
extern char ch2;

extern const uint8_t g_DESElogoImage[];

extern void homeScreen();
extern void freqAmpSelScreenCh2();
void displayWaveScreenCh2();

void print_waveform_ch2();
void includeZoomFuncCh2();
void zoomIncButFunCh2(tWidget *psWidget);
void zoomDecButFunCh2(tWidget *psWidget);
void backHomeButWFSFuncCh2(tWidget *psWidget);
void backFAButWFSFuncCh2(tWidget *psWidget);
void endCh2ButFunc(tWidget *psWidget);


#endif
