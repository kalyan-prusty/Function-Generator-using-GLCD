

#ifndef FREQAMPSELCH1_H_
#define FREQAMPSELCH1_H_


/*int freq;
float amp;
char ampStr[10], freqStr[10];*/


tPushButtonWidget freqCoarseIncButCh1, freqCoarseDecButCh1, freqFineIncButCh1,
        freqFineDecButCh1, ampCoarseIncButCh1, ampCoarseDecButCh1,
        ampFineIncButCh1, ampFineDecButCh1, backButFAS, nextButFAS;

tRectangle freqRect, freqCoarseRect, freqFineRect, ampRect, ampCoarseRect,
        ampFineRect, freqAmpRect;
extern tRectangle FuncGenRect;

extern void homeScreen();
extern void freqAmpSelScreenCh2();

void freqAmpSelScreenCh1();

void freqCoarseIncButCh1Fun(tWidget *psWidget);
void freqCoarseDecButCh1Fun(tWidget *psWidget);
void freqFineIncButCh1Fun(tWidget *psWidget);
void freqFineDecButCh1Fun(tWidget *psWidget);

void ampCoarseIncButCh1Fun(tWidget *psWidget);
void ampCoarseDecButCh1Fun(tWidget *psWidget);
void ampFineIncButCh1Fun(tWidget *psWidget);
void ampFineDecButCh1Fun(tWidget *psWidget);

void nextButFASFunc(tWidget *psWidget);
void backButFASFunc(tWidget *psWidget);


#endif
