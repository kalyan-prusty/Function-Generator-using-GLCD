

#ifndef INITIALIZEFUNCTIONS_H_
#define INITIALIZEFUNCTIONS_H_


#define BUT_NORMAL ClrDarkBlue
#define BUT_PRESS ClrDarkRed
#define BUT_TEXT_COLOR ClrWhite
#define RECT_TEXT_COLOR ClrWhite
#define RECT_FOREGROUND_COLOR ClrFireBrick
#define RECT_FREQAMP_COLOR ClrDodgerBlue
#define MAX_SAMPLES 320


extern float tri[MAX_SAMPLES];
extern float square[MAX_SAMPLES];
extern float sine[MAX_SAMPLES];
uint32_t ui32SysClock;

extern char screenChar;

tContext sContext;

tRectangle sRect,waveRect;

void makeRect(tRectangle *rect_name, short minX, short mixY, short maxX,
              short maxY, long colour, char *str);

void clr_scrn_total(void);
void clr_wave_area();
extern bool IntMasterEnable(void);

extern float freq,freqCh2;
extern float amp,ampCh2;

void ms_delay(uint32_t);
void system_init(void);
void printFreqStr(char *freqstr, float * freq);
void printAmpStr(char *ampstr, float * amp);
void DisableInterrupts(void);
void EnableInterrupts(void);
void clear_screen_grid(void);

#endif
