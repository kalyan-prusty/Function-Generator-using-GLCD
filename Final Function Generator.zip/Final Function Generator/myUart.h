#ifndef MYUART_H_
#define MYUART_H_


extern char * input_str;
extern char * temp_str;
extern char doUARTOperation;

extern float freq,freqCh2;
extern float amp,ampCh2;

//UART functions
void UART0_Handler( void );
void processString(char * temp);
char * sanitizeStringNew(char *str);
void Init_UARTA(void);
void putChar(char c);
void putString(char * s);
void putInt(int c);
void putFloatPos(float n, int r);
void putFloat(float n, int r);

#define BUSY 3

#endif /* MYUART_H_ */
