

#ifndef DISPLAYWAVEFORMCH1_H_
#define DISPLAYWAVEFORMCH1_H_

tPushButtonWidget zoomIncBut, zoomDecBut,backHomeButWFS , backFAButWFS, nextCh2But ;

tRectangle WFCh1Rect;

extern char ampStr[10],freqStr[10];
extern float freq;
extern float amp;
extern char ch1;

extern tRectangle FuncGenRect;

extern void homeScreen();
extern void displayWaveScreenCh2();
extern void freqAmpSelScreenCh1();

void displayWaveScreenCh1();
void includeZoomFunc();
void backHomeButWFSFunc(tWidget *psWidget);
void backFAButWFSFunc(tWidget *psWidget);
void nextCh2ButFunc(tWidget *psWidget);
void print_waveform_ch1();
void zoomIncButFun(tWidget *psWidget);
void zoomDecButFun(tWidget *psWidget);


#endif
