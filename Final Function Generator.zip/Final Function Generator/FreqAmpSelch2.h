
#ifndef FREQAMPSELCH2_H_
#define FREQAMPSELCH2_H_

/*extern int freqCh2; // 1 - 5
extern float ampCh2; // 1 - 3
extern char ampStrCh2[10], freqStrCh2[10];*/


tPushButtonWidget freqCoarseIncButCh2, freqCoarseDecButCh2, freqFineIncButCh2,
        freqFineDecButCh2, ampCoarseIncButCh2, ampCoarseDecButCh2,
        ampFineIncButCh2, ampFineDecButCh2, backButFASCh2, nextButFASCh2;

tRectangle freqRectCh2, freqCoarseRectCh2, freqFineRectCh2, ampRectCh2, ampCoarseRectCh2,
        ampFineRectCh2, freqAmpRectCh2;

extern tRectangle FuncGenRect;

extern void freqAmpSelScreenCh1();
extern void displayWaveScreenCh1();

void freqAmpSelScreenCh2();
void freqCoarseIncButCh2Fun(tWidget *psWidget);
void freqCoarseDecButCh2Fun(tWidget *psWidget);
void freqFineIncButCh2Fun(tWidget *psWidget);
void freqFineDecButCh2Fun(tWidget *psWidget);

void ampCoarseIncButCh2Fun(tWidget *psWidget);
void ampCoarseDecButCh2Fun(tWidget *psWidget);
void ampFineIncButCh2Fun(tWidget *psWidget);
void ampFineDecButCh2Fun(tWidget *psWidget);

void nextButFASFuncCh2(tWidget *psWidget);
void backButFASFuncCh2(tWidget *psWidget);

#endif
