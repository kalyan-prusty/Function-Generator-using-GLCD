/*
 * mySysTick.h
 *
 *  Created on: 18-Jun-2021
 *      Author: KALYAN
 */

#ifndef MYSYSTICK_H_
#define MYSYSTICK_H_

void Systick_Init(void);
void SystickHandler(void);
void sendUARTCh1Data(void);
void sendUARTCh2Data(void);

extern char ch1,ch2;
extern float freq,freqCh2;
extern float amp,ampCh2;

extern bool sendFlagCh1, sendFlagCh2;

#endif /* MYSYSTICK_H_ */
