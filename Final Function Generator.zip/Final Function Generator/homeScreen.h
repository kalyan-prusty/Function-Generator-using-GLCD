

#ifndef HOMESCREEN_H_
#define HOMESCREEN_H_

extern const uint8_t g_DESElogoImage[];

tPushButtonWidget sinButCh1, sqrButCh1, triButCh1,sinButCh2, sqrButCh2, triButCh2, endButHS, nextButHS, backBut;
tRectangle FuncGenRect, channel1Rect, channel2Rect, homeRect;

void homeScreen();

void sinButCh1Func(tWidget *psWidget);
void sqrButCh1Func(tWidget *psWidget);
void triButCh1Func(tWidget *psWidget);
void endButHSFunc(tWidget *psWidget);
void nextButHSFunc(tWidget *psWidget);

void sinButCh2Func(tWidget *psWidget);
void sqrButCh2Func(tWidget *psWidget);
void triButCh2Func(tWidget *psWidget);

extern void freqAmpSelScreenCh1();


#endif
